---
name: Bug report
about: Report an issue without sharing secrets or customer data
title: "bug: "
labels: bug
---

**What happened?**

**Steps to reproduce with synthetic test data**

**Expected behavior**

**Python version / operating system**

Do not share credentials, personal information or production payloads.
