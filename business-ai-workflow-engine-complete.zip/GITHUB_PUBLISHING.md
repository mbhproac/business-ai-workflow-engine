# Publish from GitHub.com (browser only)

**Recommended repository name:** `business-ai-workflow-engine`  
**Visibility:** Public  
**README / .gitignore / license during repository creation:** leave all disabled (included in this package).

1. Extract this ZIP using Windows **Extract All**.
2. On GitHub, create a new empty public repository named `business-ai-workflow-engine`.
3. Choose **Add file → Upload files** and drag the extracted project **contents** (not the ZIP).
4. Before committing, verify the upload includes `README.md`, `pyproject.toml`, `src/`, `tests/`, `workflows/`, and **`.github/workflows/ci.yml`**. The last item is a hidden directory on Windows and some browser upload flows skip it.
5. If `.github` is absent, do **not** upload ZIP as a replacement: use **Add file → Create new file** with the exact repository-relative path `.github/workflows/ci.yml` and paste its content from the extracted file. Repeat with `.github/dependabot.yml` and `.github/ISSUE_TEMPLATE/bug_report.md`. Always start paths at the repository root.
6. Commit with `feat: publish Business AI Workflow Engine`.
7. Visit **Actions** to check the CI results. Tests may require fixes before the project is ready for production use.

Do not commit a real `.env` file or any API keys. `.env.example` contains placeholders only.
